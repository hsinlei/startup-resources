# innovateonthehill.com

A simple website to display innovation resources at Brown and RISD. 

We're hosted on GitHub Pages, and our domain is registered with GoDaddy with the Social Innovation Initiative account. Feel free to contact either the current Innovation Groups coordinator or one of the admins of the GitHub org for the password.
